fill ~-3 -63 ~-3 ~3 -58 ~3 deepslate replace #replaceable
fill ~-2 -63 ~-2 ~2 -59 ~2 air

execute align xyz run tp @s ~0.5 -63 ~0.5
execute align xyz run setworldspawn ~0.5 -63 ~0.5

data modify storage bedrock_world_spawn:state all.init set value true