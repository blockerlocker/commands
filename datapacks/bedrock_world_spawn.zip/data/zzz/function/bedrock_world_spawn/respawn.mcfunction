scoreboard players reset @s bedrock_world_spawn
tp @s ~ -63 ~