execute unless data storage bedrock_world_spawn:state all.init as @e[type=player,limit=1] at @s run function zzz:bedrock_world_spawn/init

execute as @e[type=player,scores={bedrock_world_spawn=1..}] unless data entity @s respawn at @s run function zzz:bedrock_world_spawn/respawn