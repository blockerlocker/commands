# Go to the coordinates of the broken block
# Magic precision loss trick to snap to chunk origin (floor to multiple of 16) by ethanout from MC Commands Discord
# Run function to move chunk
$execute positioned $(x) $(y) $(z) positioned ~30000008.00001 ~30000008.00001 ~30000008.00001 \
positioned ~72057594037927936 ~72057594037927936 ~72057594037927936 \
positioned ~-72057594067927952 ~-72057594067927952 ~-72057594067927952 \
run function zzz:chunk_moves_up/player/move_chunk