# Reset block-mining detection
function bldp:mined_block/reset

# Return stored block-mining coordinates to storage for use in a macro (dividing by 10 to undo previous multiplication)
execute store result storage chunk_moves_up:temp all.x float 0.1 run scoreboard players get @s chunk_moves_up_last_x
execute store result storage chunk_moves_up:temp all.y float 0.1 run scoreboard players get @s chunk_moves_up_last_y
execute store result storage chunk_moves_up:temp all.z float 0.1 run scoreboard players get @s chunk_moves_up_last_z

# Run chunk-moving command with stored coordinates for macro
function zzz:chunk_moves_up/player/find_chunk_origin with storage chunk_moves_up:temp all