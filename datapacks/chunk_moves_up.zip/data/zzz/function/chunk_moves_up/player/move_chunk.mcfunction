# Clone chunk upwards
clone ~ ~ ~ ~15 ~15 ~15 ~ ~16 ~ strict replace move

# Teleport all moves inside of or directly on top of the chunk upwards
execute as @e[dx=15,dy=16,dz=15] at @s run tp @s ~ ~16 ~