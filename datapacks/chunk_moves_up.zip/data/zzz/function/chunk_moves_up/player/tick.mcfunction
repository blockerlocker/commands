# Detect if player has mined block and begin running the function
execute if predicate bldp:mined_block run function zzz:chunk_moves_up/player/mined_block

# Mark the block the player is currently looking at
function iris:get_target

# Storing the coordinates of the block the player is looking at in a scoreboard (multiplied by ten for mild precision)
execute store result score @s chunk_moves_up_last_x run data get entity @n[type=marker,tag=iris.targeted_block] Pos[0] 10
execute store result score @s chunk_moves_up_last_y run data get entity @n[type=marker,tag=iris.targeted_block] Pos[1] 10
execute store result score @s chunk_moves_up_last_z run data get entity @n[type=marker,tag=iris.targeted_block] Pos[2] 10