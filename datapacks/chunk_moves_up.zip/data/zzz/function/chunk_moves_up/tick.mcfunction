# Run player ticking function at all players' eyes
execute as @a at @s anchored eyes positioned ^ ^ ^ run function zzz:chunk_moves_up/player/tick