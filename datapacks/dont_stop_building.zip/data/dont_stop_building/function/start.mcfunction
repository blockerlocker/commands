data modify storage dont_stop_building:state active set value true
scoreboard players reset @a dont_stop_building
scoreboard players set @a dont_stop_building_blocks_placed 0