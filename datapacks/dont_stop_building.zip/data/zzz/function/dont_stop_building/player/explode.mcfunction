# Summon TNT to kill the player
summon tnt ~ ~ ~ {fuse:0}

# Damage the player as the TNT in case the player is too strong to die to the TNT
damage @s 999999999999999 minecraft:explosion by @n[type=tnt]

# Kill
kill @s

# Reset mining timer
scoreboard players reset @s dont_stop_building