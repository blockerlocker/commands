advancement revoke @s only dont_stop_building:placed_block

execute unless data storage dont_stop_building:state {active:true} run return fail

scoreboard players reset @s dont_stop_building
scoreboard players add @s dont_stop_building_blocks_placed 1