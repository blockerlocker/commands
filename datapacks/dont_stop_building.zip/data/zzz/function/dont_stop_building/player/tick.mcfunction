# Increase player's timer
scoreboard players add @s dont_stop_building 1


# Display countdown in center of player's screen
title @s[scores={dont_stop_building=1}] title ""
title @s[scores={dont_stop_building=1}] subtitle {text:"5",color:green}
playsound minecraft:ui.button.click ui @s[scores={dont_stop_building=1}] ~ ~ ~ 0.5 1.6

title @s[scores={dont_stop_building=21}] title ""
title @s[scores={dont_stop_building=21}] subtitle {text:"4",color:green}
playsound minecraft:ui.button.click ui @s[scores={dont_stop_building=21}] ~ ~ ~ 0.5 1.7

title @s[scores={dont_stop_building=41}] title ""
title @s[scores={dont_stop_building=41}] subtitle {text:"3",color:yellow}
playsound minecraft:ui.button.click ui @s[scores={dont_stop_building=41}] ~ ~ ~ 0.5 1.8

title @s[scores={dont_stop_building=61}] title ""
title @s[scores={dont_stop_building=61}] subtitle {text:"2",color:gold}
playsound minecraft:ui.button.click ui @s[scores={dont_stop_building=61}] ~ ~ ~ 0.5 1.9

title @s[scores={dont_stop_building=81}] title ""
title @s[scores={dont_stop_building=81}] subtitle {text:"1",color:red}
playsound minecraft:ui.button.click ui @s[scores={dont_stop_building=81}] ~ ~ ~ 0.5 2

title @s[scores={dont_stop_building=101}] title {text:"BOOM!",color:red}
title @s[scores={dont_stop_building=101}] subtitle ""


# Display number of blocks placed
title @s actionbar [{text:"Blocks Placed: ",color:aqua},{score:{name:"*",objective:dont_stop_building_blocks_placed},color:yellow}]

# Explode player after 5 seconds
execute as @s[scores={dont_stop_building=101}] run function zzz:dont_stop_building/player/explode