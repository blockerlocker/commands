scoreboard objectives add operator dummy

execute unless data storage bldp:registry all.biomes run function bldp:registry/biomes