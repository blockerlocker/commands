data modify storage find_random_biome:state all.active set value true

scoreboard players set #roll find_random_biome 120

scoreboard players reset @a find_random_biome