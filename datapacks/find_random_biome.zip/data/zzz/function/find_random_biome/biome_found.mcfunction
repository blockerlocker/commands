data modify storage find_random_biome:state all.active set value false

title @s times 10t 5s 2s
title @s title ""
title @s subtitle {text:"Biome Found!",color:green}

playsound minecraft:entity.firework_rocket.launch master @s ~ ~ ~ 1 1
playsound minecraft:entity.firework_rocket.twinkle_far master @s ~ ~ ~ 1 1
particle minecraft:firework ~ ~1 ~ 0.1 0.1 0.1 0.25 100