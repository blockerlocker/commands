$execute if predicate {condition:"minecraft:location_check",predicate:{biomes:"$(biome)"}} run function zzz:find_random_biome/biome_found

$title @s actionbar [{text:"Looking for: ",color:aqua},{translate:"biome.minecraft.$(biome)",color:yellow}]