# If #roll has a score of more than 1, randomize the biome.
execute if score #roll find_random_biome matches 1.. run function zzz:find_random_biome/roll/main

# Run active game logic once the random biome has been selected.
execute if score #roll find_random_biome matches 0 run function zzz:find_random_biome/game_active with storage find_random_biome:state all