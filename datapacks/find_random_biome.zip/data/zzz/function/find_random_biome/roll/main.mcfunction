playsound minecraft:block.shelf.place_item master @s ~ ~ ~ 1
execute if score #roll find_random_biome matches 1 run playsound minecraft:entity.experience_orb.pickup master @s ~ ~ ~ 1

scoreboard players remove #roll find_random_biome 1

function bldp:func/random/biome
data modify storage find_random_biome:temp all.biome set from storage bldp:array_random out
data modify storage find_random_biome:state all.biome set from storage bldp:array_random out

data modify storage bldp:array_random in set value [aqua,light_purple,yellow,red,green]
function bldp:func/array/random/init
data modify storage find_random_biome:temp all.text_color set from storage bldp:array_random out

title @s times 0t 5s 2s
title @s title ""
function zzz:find_random_biome/roll/subtitle with storage find_random_biome:temp all