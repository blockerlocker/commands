# Run game is active, run player tick.
execute if data storage find_random_biome:state all{active:true} as @a at @s run function zzz:find_random_biome/player_tick

# Enabled gamestart trigger for all players
execute unless data storage find_random_biome:state all{active:true} run scoreboard players enable @a find_random_biome

# Start gime when triggered
execute if entity @a[scores={find_random_biome=1..}] run function find_random_biome:start