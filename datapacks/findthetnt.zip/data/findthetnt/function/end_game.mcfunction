function zzz:findthetnt/game/cleanup

data modify storage findthetnt:world_state all.active set value false