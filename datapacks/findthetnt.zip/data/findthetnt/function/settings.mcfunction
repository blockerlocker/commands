execute at @s run playsound minecraft:block.vault.eject_item ui @s

dialog show @s {\
  "type": "minecraft:multi_action",\
  "title": "Find the TNT Settings",\
  "columns": 1,\
  "actions": [\
    {\
      "label": "Game Mode Settings",\
      "action": {\
        "type": "minecraft:run_command",\
        "command": "function zzz:findthetnt/settings/game_mode"\
      }\
    },\
    {\
      "label": "Play Area Settings",\
      "action": {\
        "type": "minecraft:run_command",\
        "command": "function zzz:findthetnt/settings/play_area/dialog with storage findthetnt:settings all.play_area"\
      }\
    }\
  ]\
}