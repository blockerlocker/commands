execute if data storage findthetnt:world_state all{active:true} run return run function zzz:findthetnt/notice/game_already_started

function zzz:findthetnt/game/cleanup

data modify storage findthetnt:world_state all.active set value true

execute store result score #findthetnt_lesser_x operator store result score #findthetnt_greater_x operator run data get storage findthetnt:settings all.play_area.center[0]
execute store result score #findthetnt_lesser_z operator store result score #findthetnt_greater_z operator run data get storage findthetnt:settings all.play_area.center[1]
execute store result score #findthetnt_radius operator run data get storage findthetnt:settings all.play_area.size 0.5

execute store result storage findthetnt:temp all.lesser_x int 1 run scoreboard players operation #findthetnt_lesser_x operator -= #findthetnt_radius operator
execute store result storage findthetnt:temp all.lesser_z int 1 run scoreboard players operation #findthetnt_lesser_z operator -= #findthetnt_radius operator

execute store result storage findthetnt:temp all.greater_z int 1 run scoreboard players operation #findthetnt_greater_z operator += #findthetnt_radius operator
execute store result storage findthetnt:temp all.greater_x int 1 run scoreboard players operation #findthetnt_greater_x operator += #findthetnt_radius operator

function zzz:findthetnt/tnt/place/roll