execute if entity @e[type=marker,tag=findthetnt_hidden_tnt,distance=..0.1] run return run function zzz:findthetnt/game/win

playsound minecraft:ui.loom.select_pattern ui @a ~ ~ ~ 0.5 1.5
particle minecraft:firework ~ ~ ~ 0.5 0.5 0.5 0.01 40

execute store result score #dist_x operator run data get entity @s Pos[0] 10
execute store result score #dist_y operator run data get entity @s Pos[1] 10
execute store result score #dist_z operator run data get entity @s Pos[2] 10

execute store result score #targ_x operator run data get entity @n[type=marker,tag=findthetnt_hidden_tnt] Pos[0] 10
execute store result score #targ_y operator run data get entity @n[type=marker,tag=findthetnt_hidden_tnt] Pos[1] 10
execute store result score #targ_z operator run data get entity @n[type=marker,tag=findthetnt_hidden_tnt] Pos[2] 10

scoreboard players operation #dist_x operator -= #targ_x operator
scoreboard players operation #dist_y operator -= #targ_y operator
scoreboard players operation #dist_z operator -= #targ_z operator

scoreboard players set #-1 operator -1

execute if score #dist_x operator matches ..0 run scoreboard players operation #dist_x operator *= #-1 operator
execute if score #dist_y operator matches ..0 run scoreboard players operation #dist_y operator *= #-1 operator
execute if score #dist_z operator matches ..0 run scoreboard players operation #dist_z operator *= #-1 operator

data modify storage findthetnt:temp all.distance_calc set value [0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,0f,1f]

execute store result storage findthetnt:temp all.distance_calc[0] float 0.1 run scoreboard players get #dist_x operator
execute store result storage findthetnt:temp all.distance_calc[4] float 0.1 run scoreboard players get #dist_y operator
execute store result storage findthetnt:temp all.distance_calc[8] float 0.1 run scoreboard players get #dist_z operator

execute at @s summon text_display run function zzz:findthetnt/flag/text

kill @s