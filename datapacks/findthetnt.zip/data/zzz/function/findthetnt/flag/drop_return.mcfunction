data modify entity @s Owner set from entity @s Thrower
data modify entity @s PickupDelay set value 0

execute on origin run tp @n[type=item,predicate=findthetnt:flag_item] @s