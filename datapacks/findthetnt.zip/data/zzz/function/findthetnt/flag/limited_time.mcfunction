scoreboard players operation #timer findthetnt_timer -= #time_lost findthetnt_timer

item modify entity @s weapon.mainhand {function:"minecraft:filtered",item_filter:{predicates:{"minecraft:custom_data":{findthetnt_flag:true}}},on_pass:{function:"minecraft:set_count",count:99}}
item modify entity @s weapon.offhand {function:"minecraft:filtered",item_filter:{predicates:{"minecraft:custom_data":{findthetnt_flag:true}}},on_pass:{function:"minecraft:set_count",count:99}}