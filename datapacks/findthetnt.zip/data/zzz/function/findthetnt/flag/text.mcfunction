data merge entity @s {billboard:center,shadow:true,text:{text:"ERROR",color:aqua,extra:[{text:" blocks away",color:aqua}]},see_through:true}
tag @s add findthetnt_text

data modify entity @s transformation set from storage findthetnt:temp all.distance_calc

execute store result storage findthetnt:temp all.distance int 1 run data get entity @s transformation.scale[0] 10
execute store result storage findthetnt:temp all.distance float 0.1 run data get storage findthetnt:temp all.distance 1

data modify entity @s transformation set value [1f,0f,0f,0f,0f,1f,0f,0f,0f,0f,1f,0f,0f,0f,0f,1f]

data modify entity @s text.text set string storage findthetnt:temp all.distance 0 -1

data remove storage findthetnt:temp all