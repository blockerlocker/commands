kill @e[type=marker,tag=findthetnt_hidden_tnt]
kill @e[type=item,predicate=findthetnt:flag_item]
kill @e[type=item_frame,predicate=findthetnt:flag]
kill @e[type=text_display,tag=findthetnt_text]
kill @e[type=item_display,tag=findthetnt_tnt_display]


clear @a item_frame[custom_data~{findthetnt_flag:true}]