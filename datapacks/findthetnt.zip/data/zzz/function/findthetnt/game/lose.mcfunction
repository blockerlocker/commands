function zzz:findthetnt/game/cleanup

summon tnt ~ ~ ~ {fuse:0,explosion_power:32}

setblock ~ ~ ~ air strict

execute summon item_display run data merge entity @s {item:{id:tnt,components:{enchantment_glint_override:true}},Tags:[findthetnt_tnt_display],transformation:{scale:[0.5,0.5,0.5]},Glowing:true}

tellraw @a [{text:"",color:yellow},{text:"[Find the TNT]",color:green},{text:" GAME OVER! The TNT was at ",color:red},{storage:"findthetnt:world_state",nbt:"all.hidden_tnt.x",plain:true},", ",{storage:"findthetnt:world_state",nbt:"all.hidden_tnt.y",plain:true},", ",{storage:"findthetnt:world_state",nbt:"all.hidden_tnt.z",plain:true}]


data modify storage findthetnt:world_state all.active set value false