scoreboard players operation #timer_visual findthetnt_timer = #timer findthetnt_timer

execute store result storage findthetnt:world_state all.timer.hours int 0.00001388888 run scoreboard players get #timer_visual findthetnt_timer
execute store result score #subtract findthetnt_timer run data get storage findthetnt:world_state all.timer.hours 72000
scoreboard players operation #timer_visual findthetnt_timer -= #subtract findthetnt_timer

execute store result storage findthetnt:world_state all.timer.minutes int 0.00083333333 run scoreboard players get #timer_visual findthetnt_timer
execute store result score #subtract findthetnt_timer run data get storage findthetnt:world_state all.timer.minutes 1200
scoreboard players operation #timer_visual findthetnt_timer -= #subtract findthetnt_timer

execute store result storage findthetnt:world_state all.timer.seconds int 0.05 run scoreboard players get #timer_visual findthetnt_timer

data modify storage findthetnt:world_state all.timer.hour_text.text set string storage findthetnt:world_state all.timer.hours
data modify storage findthetnt:world_state all.timer.minute_text.text set string storage findthetnt:world_state all.timer.minutes
data modify storage findthetnt:world_state all.timer.second_text.text set string storage findthetnt:world_state all.timer.seconds

execute if data storage findthetnt:world_state all.timer.hour_text{text:"0"} run data modify storage findthetnt:world_state all.timer.hour_text set value {text:"00"}
execute if data storage findthetnt:world_state all.timer.hour_text{text:"1"} run data modify storage findthetnt:world_state all.timer.hour_text set value {text:"01"}
execute if data storage findthetnt:world_state all.timer.hour_text{text:"2"} run data modify storage findthetnt:world_state all.timer.hour_text set value {text:"02"}
execute if data storage findthetnt:world_state all.timer.hour_text{text:"3"} run data modify storage findthetnt:world_state all.timer.hour_text set value {text:"03"}
execute if data storage findthetnt:world_state all.timer.hour_text{text:"4"} run data modify storage findthetnt:world_state all.timer.hour_text set value {text:"04"}
execute if data storage findthetnt:world_state all.timer.hour_text{text:"5"} run data modify storage findthetnt:world_state all.timer.hour_text set value {text:"05"}
execute if data storage findthetnt:world_state all.timer.hour_text{text:"6"} run data modify storage findthetnt:world_state all.timer.hour_text set value {text:"06"}
execute if data storage findthetnt:world_state all.timer.hour_text{text:"7"} run data modify storage findthetnt:world_state all.timer.hour_text set value {text:"07"}
execute if data storage findthetnt:world_state all.timer.hour_text{text:"8"} run data modify storage findthetnt:world_state all.timer.hour_text set value {text:"08"}
execute if data storage findthetnt:world_state all.timer.hour_text{text:"9"} run data modify storage findthetnt:world_state all.timer.hour_text set value {text:"09"}

execute if data storage findthetnt:world_state all.timer.minute_text{text:"0"} run data modify storage findthetnt:world_state all.timer.minute_text set value {text:"00"}
execute if data storage findthetnt:world_state all.timer.minute_text{text:"1"} run data modify storage findthetnt:world_state all.timer.minute_text set value {text:"01"}
execute if data storage findthetnt:world_state all.timer.minute_text{text:"2"} run data modify storage findthetnt:world_state all.timer.minute_text set value {text:"02"}
execute if data storage findthetnt:world_state all.timer.minute_text{text:"3"} run data modify storage findthetnt:world_state all.timer.minute_text set value {text:"03"}
execute if data storage findthetnt:world_state all.timer.minute_text{text:"4"} run data modify storage findthetnt:world_state all.timer.minute_text set value {text:"04"}
execute if data storage findthetnt:world_state all.timer.minute_text{text:"5"} run data modify storage findthetnt:world_state all.timer.minute_text set value {text:"05"}
execute if data storage findthetnt:world_state all.timer.minute_text{text:"6"} run data modify storage findthetnt:world_state all.timer.minute_text set value {text:"06"}
execute if data storage findthetnt:world_state all.timer.minute_text{text:"7"} run data modify storage findthetnt:world_state all.timer.minute_text set value {text:"07"}
execute if data storage findthetnt:world_state all.timer.minute_text{text:"8"} run data modify storage findthetnt:world_state all.timer.minute_text set value {text:"08"}
execute if data storage findthetnt:world_state all.timer.minute_text{text:"9"} run data modify storage findthetnt:world_state all.timer.minute_text set value {text:"09"}

execute if data storage findthetnt:world_state all.timer.second_text{text:"0"} run data modify storage findthetnt:world_state all.timer.second_text set value {text:"00"}
execute if data storage findthetnt:world_state all.timer.second_text{text:"1"} run data modify storage findthetnt:world_state all.timer.second_text set value {text:"01"}
execute if data storage findthetnt:world_state all.timer.second_text{text:"2"} run data modify storage findthetnt:world_state all.timer.second_text set value {text:"02"}
execute if data storage findthetnt:world_state all.timer.second_text{text:"3"} run data modify storage findthetnt:world_state all.timer.second_text set value {text:"03"}
execute if data storage findthetnt:world_state all.timer.second_text{text:"4"} run data modify storage findthetnt:world_state all.timer.second_text set value {text:"04"}
execute if data storage findthetnt:world_state all.timer.second_text{text:"5"} run data modify storage findthetnt:world_state all.timer.second_text set value {text:"05"}
execute if data storage findthetnt:world_state all.timer.second_text{text:"6"} run data modify storage findthetnt:world_state all.timer.second_text set value {text:"06"}
execute if data storage findthetnt:world_state all.timer.second_text{text:"7"} run data modify storage findthetnt:world_state all.timer.second_text set value {text:"07"}
execute if data storage findthetnt:world_state all.timer.second_text{text:"8"} run data modify storage findthetnt:world_state all.timer.second_text set value {text:"08"}
execute if data storage findthetnt:world_state all.timer.second_text{text:"9"} run data modify storage findthetnt:world_state all.timer.second_text set value {text:"09"}

title @a actionbar [{storage:"findthetnt:world_state",nbt:all.timer.hour_text,color:green,interpret:true},":",{storage:"findthetnt:world_state",nbt:all.timer.minute_text,interpret:true},":",{storage:"findthetnt:world_state",nbt:all.timer.second_text,interpret:true}]