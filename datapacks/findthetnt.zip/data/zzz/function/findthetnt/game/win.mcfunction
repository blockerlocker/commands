execute as @a at @s run playsound minecraft:entity.firework_rocket.launch ui @s
particle minecraft:happy_villager ~ ~ ~ 0.3 0.3 0.3 0 40

title @a title ""
title @a subtitle {text:"You Found the TNT!",color:green}
tellraw @a [{text:"[Find the TNT]",color:green},{text:" You made ",color:yellow},{score:{name:"#total_guesses",objective:findthetnt_guesses}},{text:" guesses!",color:yellow}]

setblock ~ ~ ~ air strict

function zzz:findthetnt/game/cleanup

execute summon item_display run data merge entity @s {item:{id:tnt,components:{enchantment_glint_override:true}},Tags:[findthetnt_tnt_display],transformation:{scale:[0.5,0.5,0.5]},Glowing:true}

data modify storage findthetnt:world_state all.active set value false

kill @s