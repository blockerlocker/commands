scoreboard objectives add operator dummy
scoreboard objectives add findthetnt_timer dummy
scoreboard objectives add findthetnt_guesses dummy
scoreboard objectives add findthetnt_used_item_frame minecraft.used:item_frame

advancement revoke @a only findthetnt:placed_flag

execute unless data storage findthetnt:settings all run function zzz:findthetnt/settings/init