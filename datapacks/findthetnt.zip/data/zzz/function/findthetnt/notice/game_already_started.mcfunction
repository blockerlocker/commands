execute at @s run playsound block.note_block.bass ui @s

tellraw @s [{text:"[Find the TNT]",color:green},{text:" The game is already active! End the game with '/function findthetnt:end_game'",color:red}]