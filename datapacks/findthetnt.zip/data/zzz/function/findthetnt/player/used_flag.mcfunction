advancement revoke @s only findthetnt:placed_flag

scoreboard players reset @s findthetnt_used_item_frame

execute unless entity @e[type=item_frame,predicate=findthetnt:flag] run return fail

scoreboard players add #total_guesses findthetnt_guesses 1

execute as @n[type=item_frame,predicate=findthetnt:flag] at @s positioned ^ ^ ^-0.5 align xyz positioned ~0.5 ~0.5 ~0.5 run function zzz:findthetnt/flag/check

execute if data storage findthetnt:world_state all{active:true,game_mode:limited_guesses} unless items entity @s container.* item_frame[custom_data~{findthetnt_flag:true}] run function zzz:findthetnt/game/lose
execute if data storage findthetnt:world_state all{active:true,game_mode:limited_time} run function zzz:findthetnt/flag/limited_time