data merge storage findthetnt:settings {all:{game_mode:limited_guesses,limited_time:{units:minutes,time_limit:30,time_lost:1},limited_guesses:{total_guesses:24},play_area:{center:[0,0],center_x:"0.0",center_z:"0.0",size:64}}}

function zzz:findthetnt/settings/play_area/set with storage findthetnt:settings all.play_area
worldborder center 0.0 0.0