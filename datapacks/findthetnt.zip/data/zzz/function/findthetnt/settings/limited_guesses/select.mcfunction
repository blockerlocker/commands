data modify storage findthetnt:settings all.game_mode set value limited_guesses
execute at @s run playsound minecraft:block.vault.insert_item ui @s ~ ~ ~ 1 2
tellraw @s [{text:"[Find the TNT]",color:green},{text:" Game mode set to Limited Guesses.",color:yellow}]

$dialog show @s {\
  "type": "minecraft:multi_action",\
  "title": "Find the TNT Settings",\
  "body": {\
    "type": "minecraft:plain_message",\
    "contents": [\
      {\
        "text": "Select Game Mode\n",\
        "color": "green"\
      },\
      {\
        "text": "| ",\
        "color": "aqua"\
      },\
      {\
        "text": "[Limited Time]",\
        "color": "white",\
        "click_event": {\
          "action": "run_command",\
          "command": "function zzz:findthetnt/settings/limited_time/select"\
        },\
        "hover_event": {\
          "action": "show_text",\
          "value": "Select Mode"\
        }\
      },\
      {\
        "text": " | ",\
        "color": "aqua"\
      },\
      {\
        "text": "[Guess Limit]",\
        "color": "gold",\
        "bold": true,\
        "hover_event": {\
          "action": "show_text",\
          "value": "Already Selected"\
        }\
      },\
      {\
        "text": " |",\
        "color": "aqua"\
      }\
    ]\
  },\
  "inputs": [\
    {\
      "type": "minecraft:text",\
      "key": "total_guesses",\
      "width": 100,\
      "label": "Total Guesses",\
      "initial": "$(total_guesses)"\
    }\
  ],\
  "pause": true,\
  "columns": 1,\
  "actions": [\
    {\
      "label": "Save and Quit",\
      "width": 200,\
      "action": {\
        "type": "minecraft:dynamic/run_command",\
        "template": "function zzz:findthetnt/settings/limited_guesses/set {total_guesses:\u0024(total_guesses)}"\
      }\
    },\
    {\
      "label": "Quit without Saving",\
      "width": 200\
    }\
  ]\
}