$data merge storage findthetnt:settings {all:{limited_guesses:{total_guesses:$(total_guesses)}}}

execute at @s run playsound minecraft:block.vault.insert_item ui @s ~ ~ ~ 1 2

$tellraw @s [{text:"[Find the TNT]",color:green},{text:" Settings saved! Game lasts indefinitely, but ends after $(total_guesses) guesses.",color:yellow}]