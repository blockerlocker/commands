$dialog show @s {\
  "type": "minecraft:multi_action",\
  "title": "Find the TNT Settings",\
  "body": {\
    "type": "minecraft:plain_message",\
    "contents": [\
      {\
        "text": "Select Game Mode\n",\
        "color": "green"\
      },\
      {\
        "text": "| ",\
        "color": "aqua"\
      },\
      {\
        "text": "[Limited Time]",\
        "color": "gold",\
        "bold": true,\
        "hover_event": {\
          "action": "show_text",\
          "value": "Already Selected"\
        }\
      },\
      {\
        "text": " | ",\
        "color": "aqua"\
      },\
      {\
        "text": "[Guess Limit]",\
        "color": "white",\
        "click_event": {\
          "action": "run_command",\
          "command": "function zzz:findthetnt/settings/limited_guesses/select with storage findthetnt:settings all.limited_guesses"\
        },\
        "hover_event": {\
          "action": "show_text",\
          "value": "Select Mode"\
        }\
      },\
      {\
        "text": " |",\
        "color": "aqua"\
      }\
    ]\
  },\
  "inputs": [\
    {\
      "type": "minecraft:single_option",\
      "key": "units",\
      "width": 150,\
      "label": "Time Units",\
      "options": [\
        {\
          "id": "minutes",\
          "display": "Minutes",\
          "initial":$(minutes_initial)\
        },\
        {\
          "id": "seconds",\
          "display": "Seconds",\
          "initial":$(seconds_initial)\
        },\
        {\
          "id": "ticks",\
          "display": "Ticks",\
          "initial":$(ticks_initial)\
        }\
      ]\
    },\
    {\
      "type": "minecraft:text",\
      "key": "time_limit",\
      "width": 100,\
      "label": "Time Limit",\
      "initial": "$(time_limit)"\
    },\
    {\
      "type": "minecraft:text",\
      "key": "time_lost",\
      "width": 100,\
      "label": "Time Lost on Flag",\
      "initial": "$(time_lost)"\
    }\
  ],\
  "pause": true,\
  "columns": 1,\
  "actions": [\
    {\
      "label": "Save and Quit",\
      "width": 200,\
      "action": {\
        "type": "minecraft:dynamic/run_command",\
        "template": "function zzz:findthetnt/settings/limited_time/set {units:\u0024(units),time_limit:\u0024(time_limit),time_lost:\u0024(time_lost)}"\
      }\
    },\
    {\
      "label": "Quit without Saving",\
      "width": 200\
    }\
  ]\
}