data modify storage findthetnt:settings all.game_mode set value limited_time
execute at @s run playsound minecraft:block.vault.insert_item ui @s ~ ~ ~ 1 2
tellraw @s [{text:"[Find the TNT]",color:green},{text:" Game mode set to Limited Time.",color:yellow}]


execute if data storage findthetnt:settings all.limited_time{units:minutes} run data merge storage findthetnt:settings {all:{limited_time:{minutes_initial:"true",seconds_initial:"false",ticks_initial:"false"}}}
execute if data storage findthetnt:settings all.limited_time{units:seconds} run data merge storage findthetnt:settings {all:{limited_time:{minutes_initial:"false",seconds_initial:"true",ticks_initial:"false"}}}
execute if data storage findthetnt:settings all.limited_time{units:ticks} run data merge storage findthetnt:settings {all:{limited_time:{minutes_initial:"false",seconds_initial:"false",ticks_initial:"true"}}}

function zzz:findthetnt/settings/limited_time/dialog with storage findthetnt:settings all.limited_time