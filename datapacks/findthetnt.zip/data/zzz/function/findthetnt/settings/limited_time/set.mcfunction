$data merge storage findthetnt:settings {all:{limited_time:{units:$(units),time_limit:$(time_limit),time_lost:$(time_lost)}}}

execute at @s run playsound minecraft:block.vault.insert_item ui @s ~ ~ ~ 1 2

$tellraw @s [{text:"[Find the TNT]",color:green},{text:" Settings saved! Game lasts $(time_limit) $(units), and $(time_lost) $(units) are lost with every failed guess.",color:yellow}]