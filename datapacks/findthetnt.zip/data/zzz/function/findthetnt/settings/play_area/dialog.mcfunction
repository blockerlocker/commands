execute at @s run playsound minecraft:block.vault.insert_item ui @s ~ ~ ~ 1 2

$dialog show @s {\
  "type": "minecraft:multi_action",\
  "title": "Find the TNT Settings",\
  "body": {\
    "type": "minecraft:plain_message",\
    "contents": [\
      "Play Area is the diameter of the area in blocks, similar to how to how the World Border works.\n\nThe center of the Play Area can be set with:\n",\
      {\
        "text": "/function findthetnt:set_world_center",\
        "color": "yellow",\
        "click_event": {\
          "action": "suggest_command",\
          "command": "/function findthetnt:set_world_center"\
        },\
        "hover_event": {\
          "action": "show_text",\
          "value": "Run command"\
        }\
      }\
    ]\
  },\
  "inputs": [\
    {\
      "type": "minecraft:text",\
      "key": "size",\
      "width": 100,\
      "label": "Play Area Size",\
      "initial": "$(size)"\
    }\
  ],\
  "actions": [\
    {\
      "label": "Save and Quit",\
      "action": {\
        "type": "minecraft:dynamic/run_command",\
        "template": "function zzz:findthetnt/settings/play_area/set {size:\u0024(size)}"\
      }\
    }\
  ]\
}