$data merge storage findthetnt:settings {all:{play_area:{size:$(size)}}}

$worldborder set $(size)

execute at @s run playsound minecraft:block.vault.insert_item ui @s ~ ~ ~ 1 2

$tellraw @s [{text:"[Find the TNT]",color:green},{text:" Play Area set to $(size) by $(size) blocks.",color:yellow}]