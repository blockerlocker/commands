summon marker ~ ~ ~ {Tags:[findthetnt_world_center]}

data modify storage findthetnt:settings all.play_area.center[0] set from entity @n[type=marker,tag=findthetnt_world_center] Pos[0]
data modify storage findthetnt:settings all.play_area.center[1] set from entity @n[type=marker,tag=findthetnt_world_center] Pos[2]

kill @e[type=marker,tag=findthetnt_world_center]

data modify storage findthetnt:settings all.play_area.center_x set string storage findthetnt:settings all.play_area.center[0] 0 -1
data modify storage findthetnt:settings all.play_area.center_z set string storage findthetnt:settings all.play_area.center[1] 0 -1

worldborder center ~ ~