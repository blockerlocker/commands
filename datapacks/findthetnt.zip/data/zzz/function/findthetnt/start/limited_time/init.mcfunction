loot give @a loot findthetnt:flag/full_stack

execute if data storage findthetnt:settings all.limited_time{units:ticks} store result score #timer findthetnt_timer run data get storage findthetnt:settings all.limited_time.time_limit
execute if data storage findthetnt:settings all.limited_time{units:seconds} store result score #timer findthetnt_timer run data get storage findthetnt:settings all.limited_time.time_limit 20
execute if data storage findthetnt:settings all.limited_time{units:minutes} store result score #timer findthetnt_timer run data get storage findthetnt:settings all.limited_time.time_limit 1200

execute if data storage findthetnt:settings all.limited_time{units:ticks} store result score #time_lost findthetnt_timer run data get storage findthetnt:settings all.limited_time.time_lost
execute if data storage findthetnt:settings all.limited_time{units:seconds} store result score #time_lost findthetnt_timer run data get storage findthetnt:settings all.limited_time.time_lost 20
execute if data storage findthetnt:settings all.limited_time{units:minutes} store result score #time_lost findthetnt_timer run data get storage findthetnt:settings all.limited_time.time_lost 1200