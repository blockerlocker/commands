execute as @a at @s run playsound minecraft:entity.tnt.primed ui @s
title @a title ""
title @a subtitle {text:"Find the TNT!",color:yellow}

scoreboard players reset #total_guesses findthetnt_guesses

data modify storage findthetnt:world_state all.game_mode set from storage findthetnt:settings all.game_mode
execute if data storage findthetnt:world_state all{game_mode:limited_time} run function zzz:findthetnt/start/limited_time/init
execute if data storage findthetnt:world_state all{game_mode:limited_guesses} run function zzz:findthetnt/start/limited_guesses/init