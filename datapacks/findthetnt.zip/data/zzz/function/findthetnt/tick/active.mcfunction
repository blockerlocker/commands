execute if data storage findthetnt:world_state all{game_mode:limited_time} run function zzz:findthetnt/tick/limited_time

execute at @n[type=marker,tag=findthetnt_hidden_tnt] if block ~ ~ ~ #findthetnt:invalid run function zzz:findthetnt/game/lose

execute as @e[type=item,predicate=findthetnt:flag_item] at @s run function zzz:findthetnt/flag/drop_return