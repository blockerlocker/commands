execute unless score #timer findthetnt_timer matches ..0 run scoreboard players remove #timer findthetnt_timer 1
function zzz:findthetnt/game/timer_visual
execute if score #timer findthetnt_timer matches ..0 at @n[type=marker,tag=findthetnt_hidden_tnt] run function zzz:findthetnt/game/lose