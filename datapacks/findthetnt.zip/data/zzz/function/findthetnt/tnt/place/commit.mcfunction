summon marker ~ ~0.5 ~ {Tags:["findthetnt_hidden_tnt"]}

data modify storage findthetnt:world_state all.hidden_tnt.x set from storage findthetnt:temp all.random_x
data modify storage findthetnt:world_state all.hidden_tnt.y set from storage findthetnt:temp all.random_y
data modify storage findthetnt:world_state all.hidden_tnt.z set from storage findthetnt:temp all.random_z

function zzz:findthetnt/start/main

data remove storage findthetnt:temp all