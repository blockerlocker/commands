$execute store result storage findthetnt:temp all.random_x int 1 run random value $(lesser_x)..$(greater_x)
execute store result storage findthetnt:temp all.random_y int 1 run random value -64..319
$execute store result storage findthetnt:temp all.random_z int 1 run random value $(lesser_z)..$(greater_z)