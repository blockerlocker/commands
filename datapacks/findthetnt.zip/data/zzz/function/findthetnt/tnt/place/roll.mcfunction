function zzz:findthetnt/tnt/place/random_coordinate with storage findthetnt:temp all
function zzz:findthetnt/tnt/place/test_location with storage findthetnt:temp all