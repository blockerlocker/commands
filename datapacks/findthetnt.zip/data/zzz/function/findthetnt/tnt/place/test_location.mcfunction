$execute positioned $(random_x) $(random_y) $(random_z) unless block ~ ~ ~ #findthetnt:invalid run return run function zzz:findthetnt/tnt/place/commit

function zzz:findthetnt/tnt/place/roll