gamerule max_block_modifications 66049
scoreboard objectives add interlaced dummy
execute unless score #current_slice interlaced matches -63.. run scoreboard players set #current_slice interlaced -63