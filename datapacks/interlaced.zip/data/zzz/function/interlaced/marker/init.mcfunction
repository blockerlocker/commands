tag @s add interlaced_marker
scoreboard players set @s interlaced -63