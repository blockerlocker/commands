execute store result storage interlaced:temp all.layer int 1 run scoreboard players get @s interlaced
function zzz:interlaced/marker/fill_line with storage interlaced:temp all
scoreboard players add @s interlaced 2