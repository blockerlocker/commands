execute \
positioned ~30000008.00001 ~ ~30000008.00001 \
positioned ~72057594037927936 ~ ~72057594037927936 \
positioned ~-72057594067927952 ~ ~-72057594067927952 \
unless entity @e[type=marker,tag=interlaced_marker,distance=..1] \
summon marker run function zzz:interlaced/marker/init