function zzz:interlaced/marker/next_line
function zzz:interlaced/marker/next_line
function zzz:interlaced/marker/next_line


execute if score @s interlaced matches 321.. run tag @s add interlaced_complete