execute as @a at @s run function zzz:interlaced/player_tick

execute as @e[type=marker,tag=interlaced_marker,tag=!interlaced_complete] at @s run function zzz:interlaced/marker/tick