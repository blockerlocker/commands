# Reset block-mining detection
function bldp:picked_up_item/reset

# If player is on surface, run normal spreadplayers command
execute if predicate {condition:"minecraft:location_check",predicate:{can_see_sky:1b}} run return run spreadplayers ~ ~ 0 10000 false @s

# If player is not on surface, grab their current y value and add 20 to it
execute store result score #item_random_teleport operator run data get entity @s Pos[1]
execute store result storage item_random_teleport:temp all.y int 1 run scoreboard players add #item_random_teleport operator 20

# Run spreadplayers command under previously stored y value
function zzz:item_random_teleport/player/spreadplayers_under with storage item_random_teleport:temp all

# Cleanup data storage
data remove storage item_random_teleport:temp all
scoreboard players reset #item_random_teleport operator