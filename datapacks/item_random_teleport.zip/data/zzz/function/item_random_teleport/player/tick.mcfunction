# Detect if player has mined block and begin running the function
execute if predicate bldp:picked_up_item run function zzz:item_random_teleport/player/mined_block