# Cancel function if player's inventory is full
execute if data entity @p[tag=long_arms_grab] Inventory[35] run return fail

# Give player dropped item, play pickup sound, and kill item entity
loot give @p[tag=long_arms_grab] loot {pools:[{rolls:1,entries:[{type:slots,slot_source:{type:slot_range,source:this,slots:contents}}]}]}
execute as @p[tag=long_arms_grab] at @s run playsound entity.item.pickup player @s ~ ~ ~ 0.3 2
kill @s