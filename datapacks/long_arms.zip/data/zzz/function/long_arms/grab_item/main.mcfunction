# Reset scoreboards that detect mining a block
function bldp:mined_block/reset

# Grab last-target coordinates from player storage
$data modify storage long_arms:temp all.mined_x set from storage long_arms:players all[{UUID:$(UUID)}].last_x
$data modify storage long_arms:temp all.mined_y set from storage long_arms:players all[{UUID:$(UUID)}].last_y
$data modify storage long_arms:temp all.mined_z set from storage long_arms:players all[{UUID:$(UUID)}].last_z

# Tag player and find dropped items
tag @s add long_arms_grab
function zzz:long_arms/grab_item/find_items with storage long_arms:temp all
tag @s remove long_arms_grab