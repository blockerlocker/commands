advancement revoke @s only long_arms:kill_mob

tag @s add long_arms_killed_mob