attribute @s block_interaction_range base set 64
attribute @s entity_interaction_range base set 64