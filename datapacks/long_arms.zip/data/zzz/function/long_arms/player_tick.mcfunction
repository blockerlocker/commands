# Zoom camera if player is holding both sprint and crouch simulatenously.
attribute @s movement_speed modifier remove bldp:zoom
execute if predicate {condition:"entity_properties",entity:"this",predicate:{"type_specific/player":{input:{sneak:true,sprint:true}}}} run attribute @s movement_speed modifier add bldp:zoom -1 add_multiplied_total

# If player broke block or killed mob, attempt to grab dropped items.
execute if predicate bldp:mined_block run function zzz:long_arms/grab_item/main with entity @s
execute if entity @s[tag=long_arms_killed_mob] run function zzz:long_arms/grab_item/main with entity @s

# Run raycast to get target
data merge storage iris:settings {MaxRecursionDepth:96,TargetEntities:true}
function iris:get_target

# Set data for storing target coordinates
data modify storage long_arms:temp all.UUID set from entity @s UUID
data modify storage long_arms:temp all merge value {target_x:null,target_y:null,target_z:null}

data modify storage long_arms:temp all.target_x set from entity @n[type=marker,tag=iris.targeted_block] Pos[0]
data modify storage long_arms:temp all.target_y set from entity @n[type=marker,tag=iris.targeted_block] Pos[1]
data modify storage long_arms:temp all.target_z set from entity @n[type=marker,tag=iris.targeted_block] Pos[2]

data modify storage long_arms:temp all.target_y set from entity @n[tag=iris.targeted_entity] Pos[1]
data modify storage long_arms:temp all.target_z set from entity @n[tag=iris.targeted_entity] Pos[2]
data modify storage long_arms:temp all.target_x set from entity @n[tag=iris.targeted_entity] Pos[0]

# Store target coordinates
function zzz:long_arms/store_last_target with storage long_arms:temp all

# Cleanup
data remove storage long_arms:temp all
tag @s remove long_arms_killed_mob