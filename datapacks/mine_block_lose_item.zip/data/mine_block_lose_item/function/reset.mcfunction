data remove storage mine_block_lose_item:data all.disabled

function zzz:mine_block_lose_item/list/create