advancement revoke @s only mine_block_lose_item:inventory_changed

function zzz:mine_block_lose_item/player/clear_disabled with storage mine_block_lose_item:data all