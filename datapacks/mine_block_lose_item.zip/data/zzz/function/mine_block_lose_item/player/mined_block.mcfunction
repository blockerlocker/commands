function bldp:mined_block/reset

data modify storage bldp:array_random in set from storage mine_block_lose_item:data all.enabled
function bldp:func/array/random/init

data modify storage mine_block_lose_item:data all.disabled append from storage bldp:array_random out.item

function zzz:mine_block_lose_item/list/remove_from_enabled with storage bldp:array_random

execute as @a at @s run function zzz:mine_block_lose_item/player/notice with storage bldp:array_random out