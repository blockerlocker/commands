scoreboard objectives add operator dummy

function bldp:registry/icon/item