# Initialize player's list of known recipes
function zzz:mine_block_lose_recipe/player/init/macro with entity @s

# Grant every advancement, and remove any earned XP. Advancements must be disabled since many of them grant recipes
advancement grant @s everything
xp add @s -43 levels
xp add @s -100 points

# Remove every recipe from the player
recipe give @a *