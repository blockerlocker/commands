# Reset block-mining detection
function bldp:mined_block/reset

# Inform player if they've run out of recipes
$execute unless data storage mine_block_lose_recipe:recipes all.player[{UUID:$(UUID)}].recipes[0] run return run function zzz:mine_block_lose_recipe/player/no_more_recipes

# Grab a random item from the player's list of known recipes, utilizing bldp's random array function
$data modify storage bldp:array_random in set from storage mine_block_lose_recipe:recipes all.player[{UUID:$(UUID)}].recipes
function bldp:func/array/random/init

# Store the player's UUID and the random item for use together in a function macro
data modify storage mine_block_lose_recipe:temp all.UUID set from entity @s UUID
data modify storage mine_block_lose_recipe:temp all.item set from storage bldp:array_random out

# Remove selected random item from player's list of known recipes
function zzz:mine_block_lose_recipe/player/remove_item with storage mine_block_lose_recipe:temp all

# Revoke the recipes themselves to make the item uncraftable
function zzz:mine_block_lose_recipe/player/take_recipes/loop

# Alert the player which item they can no longer craft
function zzz:mine_block_lose_recipe/player/notice with storage mine_block_lose_recipe:temp all.item

# Cleanup
data remove storage mine_block_lose_recipe:temp all