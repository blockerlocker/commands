tellraw @s {text:"You have forgotten every recipe!",color:red}
playsound block.note_block.bass ui @s ~ ~ ~ 1 1