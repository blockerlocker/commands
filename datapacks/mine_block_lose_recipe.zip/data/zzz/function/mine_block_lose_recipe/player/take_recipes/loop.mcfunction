# Store first recipe for use in macro
data modify storage mine_block_lose_recipe:temp all.take_recipe set from storage mine_block_lose_recipe:temp all.item.recipes[0]

# Take recipe from player
function zzz:mine_block_lose_recipe/player/take_recipes/take with storage mine_block_lose_recipe:temp all

# Remove first recipe in list
data remove storage mine_block_lose_recipe:temp all.item.recipes[0]

# If there are still recipes for this item, loop this function
execute if data storage mine_block_lose_recipe:temp all.item.recipes[0] run function zzz:mine_block_lose_recipe/player/take_recipes/loop