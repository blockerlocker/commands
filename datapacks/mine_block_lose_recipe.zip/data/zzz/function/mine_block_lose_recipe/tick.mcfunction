# When the player mines a block, run a function
execute as @a if predicate bldp:mined_block at @s run function zzz:mine_block_lose_recipe/player/mined with entity @s