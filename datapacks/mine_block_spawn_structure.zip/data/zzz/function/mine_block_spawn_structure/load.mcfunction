# Setup scoreboards for storing the coordinates of the block the player is looking at
scoreboard objectives add blockerlocker_last_target_x dummy
scoreboard objectives add blockerlocker_last_target_y dummy
scoreboard objectives add blockerlocker_last_target_z dummy

# Setup list of all structures
data modify storage mine_block_spawn_structure:structures all set value [\
  {name:"Ancient City",template:"mine_block_spawn_structure:ancient_city",coordinates:"~-108 ~-2 ~-108"},\
  {name:"Bastion Remnant",template:"mine_block_spawn_structure:bastion_remnant",coordinates:"~-31 ~-2 ~-25"},\
  {name:"Buried Treasure",template:"mine_block_spawn_structure:buried_treasure",coordinates:"~ ~ ~"},\
  {name:"Desert Pyramid",template:"mine_block_spawn_structure:desert_pyramid",coordinates:"~-10 ~-15 ~-10"},\
  {name:"End City",template:"mine_block_spawn_structure:end_city",coordinates:"~-30 ~-1 ~-56"},\
  {name:"Fortress",template:"mine_block_spawn_structure:fortress",coordinates:"~-74 ~-5 ~-68"},\
  {name:"Igloo",template:"mine_block_spawn_structure:igloo",coordinates:"~-3 ~ ~-4"},\
  {name:"Jungle Pyramid",template:"mine_block_spawn_structure:jungle_pyramid",coordinates:"~-7 ~-5 ~-6"},\
  {name:"Mansion",template:"mine_block_spawn_structure:mansion",coordinates:"~-39 ~-3 ~-30"},\
  {name:"Mesa Mineshaft",template:"mine_block_spawn_structure:mineshaft_mesa",coordinates:"~-59 ~-8 ~-61"},\
  {name:"Mineshaft",template:"mine_block_spawn_structure:mineshaft",coordinates:"~-54 ~-13 ~-73"},\
  {name:"Monument",template:"mine_block_spawn_structure:monument",coordinates:"~-29 ~-4 ~-29"},\
  {name:"Nether Fossil",template:"mine_block_spawn_structure:nether_fossil",coordinates:"~-3 ~-1 ~-3"},\
  {name:"Cold Ocean Ruin",template:"mine_block_spawn_structure:ocean_ruin_cold",coordinates:"~-15 ~ ~-23"},\
  {name:"Warm Ocean Ruin",template:"mine_block_spawn_structure:ocean_ruin_warm",coordinates:"~-19 ~ ~-18"},\
  {name:"Pillager Outpost",template:"mine_block_spawn_structure:pillager_outpost",coordinates:"~-22 ~ ~-22"},\
  {name:"Desert Ruined Portal",template:"mine_block_spawn_structure:ruined_portal_desert",coordinates:"~-4 ~ ~-3"},\
  {name:"Jungle Ruined Portal",template:"mine_block_spawn_structure:ruined_portal_jungle",coordinates:"~-5 ~ ~-5"},\
  {name:"Moutain Ruined Portal",template:"mine_block_spawn_structure:ruined_portal_mountain",coordinates:"~-3 ~ ~-4"},\
  {name:"Nether Ruined Portal",template:"mine_block_spawn_structure:ruined_portal_nether",coordinates:"~-5 ~ ~-3"},\
  {name:"Ocean Ruined Portal",template:"mine_block_spawn_structure:ruined_portal_ocean",coordinates:"~-2 ~ ~-3"},\
  {name:"Swamp Ruined Portal",template:"mine_block_spawn_structure:ruined_portal_swamp",coordinates:"~-3 ~ ~-2"},\
  {name:"Ruined Portal",template:"mine_block_spawn_structure:ruined_portal",coordinates:"~-3 ~ ~-5"},\
  {name:"Beached Shipwreck",template:"mine_block_spawn_structure:shipwreck_beached",coordinates:"~-4 ~ ~-7"},\
  {name:"Shipwreck",template:"mine_block_spawn_structure:shipwreck",coordinates:"~-4 ~ ~-14"},\
  {name:"Stronghold",template:"mine_block_spawn_structure:stronghold",coordinates:"~-78 ~-11 ~-41"},\
  {name:"Swamp Hut",template:"mine_block_spawn_structure:swamp_hut",coordinates:"~-4 ~ ~-3"},\
  {name:"Trail Ruins",template:"mine_block_spawn_structure:trail_ruins",coordinates:"~-9 ~-20 ~-37"},\
  {name:"Trial Chambers",template:"mine_block_spawn_structure:trial_chambers",coordinates:"~-59 ~-28 ~-53"},\
  {name:"Desert Village",template:"mine_block_spawn_structure:village_desert",coordinates:"~-45 ~-1 ~-38"},\
  {name:"Plains Village",template:"mine_block_spawn_structure:village_plains",coordinates:"-72 ~-1 ~-76"},\
  {name:"Savanna Village",template:"mine_block_spawn_structure:village_savanna",coordinates:"-49 ~-1 ~-76"},\
  {name:"Snowy Village",template:"mine_block_spawn_structure:village_snowy",coordinates:"-46 ~-1 ~-67"},\
  {name:"Taiga Village",template:"mine_block_spawn_structure:village_taiga",coordinates:"-74 ~-1 ~-65"}\
]