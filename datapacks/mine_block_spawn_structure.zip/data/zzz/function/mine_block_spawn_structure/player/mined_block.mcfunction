# Reset block-mining detection
function bldp:mined_block/reset

# Return stored block-mining coordinates to storage for use in a macro
execute store result storage blockerlocker:temp all.x float 1 run scoreboard players get @s blockerlocker_last_target_x
execute store result storage blockerlocker:temp all.y float 1 run scoreboard players get @s blockerlocker_last_target_y
execute store result storage blockerlocker:temp all.z float 1 run scoreboard players get @s blockerlocker_last_target_z

# Get a random structure
data modify storage bldp:array_random in set from storage mine_block_spawn_structure:structures all
function bldp:func/array/random/init
data modify storage blockerlocker:temp all.structure set from storage bldp:array_random out

# Move template and coordinates to base of data structure for use in macro
data modify storage blockerlocker:temp all.template set from storage blockerlocker:temp all.structure.template
data modify storage blockerlocker:temp all.coordinates set from storage blockerlocker:temp all.structure.coordinates

# Run function to spawn structure with stored macro data
function zzz:mine_block_spawn_structure/player/spawn_structure with storage blockerlocker:temp all

# If player is inside of blocks, give them air
execute at @s anchored eyes positioned ^ ^ ^ unless block ~ ~ ~ air run fill ~0.3 ~ ~0.3 ~-0.3 ~ ~-0.3 air

# Notify player of spawned structure
tellraw @s [{text:"Spawned ",color:yellow},{storage:"blockerlocker:temp",nbt:"all.structure.name",color:aqua,interpret:true}]

# Cleanup data storage
data remove storage blockerlocker:temp all