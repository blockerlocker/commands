# Detect if player has mined block and begin running the function
execute if predicate bldp:mined_block run function zzz:mine_block_spawn_structure/player/mined_block

# Mark the block the player is currently looking at
function iris:get_target

# Store the coordinates of the block the player is looking at in a scoreboard
execute store result score @s blockerlocker_last_target_x run data get entity @n[type=marker,tag=iris.targeted_block] Pos[0]
execute store result score @s blockerlocker_last_target_y run data get entity @n[type=marker,tag=iris.targeted_block] Pos[1]
execute store result score @s blockerlocker_last_target_z run data get entity @n[type=marker,tag=iris.targeted_block] Pos[2]