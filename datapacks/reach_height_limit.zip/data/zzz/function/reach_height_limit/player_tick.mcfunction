execute store result storage reach_height_limit:temp all.y int 1 store result score @s reach_height_limit run data get entity @s Pos[1]

execute store result storage reach_height_limit:temp all.distance int -1 run scoreboard players remove @s reach_height_limit 319

title @s actionbar [{text:"Height: ",color:aqua},{storage:"reach_height_limit:temp",nbt:"all.y",plain:true,color:gold},{text:" (",color:yellow},{storage:"reach_height_limit:temp",nbt:"all.distance",plain:true,color:yellow},{text:" to go)",color:yellow}]

execute if score @s[tag=!reached_height_limit] reach_height_limit matches 0.. at @s run function zzz:reach_height_limit/reached_height_limit
title @s[tag=reached_height_limit] actionbar [{text:"Height: ",color:green},{storage:"reach_height_limit:temp",nbt:"all.y",plain:true,color:green}]

tag @s[scores={reach_height_limit=..-1}] remove reached_height_limit