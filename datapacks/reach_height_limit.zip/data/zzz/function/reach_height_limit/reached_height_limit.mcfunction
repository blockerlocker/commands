tag @s add reached_height_limit

playsound entity.firework_rocket.launch master @s ~ ~ ~ 1 1
title @s title ""
title @s subtitle {text:"Reached Height Limit!",color:green}