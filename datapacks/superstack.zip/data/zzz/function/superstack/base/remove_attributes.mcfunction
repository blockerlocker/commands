attribute @s movement_speed modifier remove superstack:freeze
attribute @s step_height modifier remove superstack:step