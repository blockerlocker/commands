# If the base entity has no vehicle, stack to nearest mob that has no passenger, and play a sound.
execute store success storage superstack:temp all.ride_success byte 1 unless predicate superstack:has_vehicle run ride @s mount @n[nbt={Brain:{}},distance=..2,predicate=!superstack:has_passenger,type=!player]
execute if data storage superstack:temp all{ride_success:true} as @p[tag=superstack] at @s run playsound minecraft:block.sniffer_egg.plop ui @s

# Apply attribute modifiers
attribute @s movement_speed modifier add superstack:freeze -1 add_multiplied_total
attribute @s step_height modifier add superstack:step 1 add_value

# Apply strafe
data modify entity @s Motion[0] set from storage superstack:temp all.strafe_vector[0]
data modify entity @s Motion[2] set from storage superstack:temp all.strafe_vector[2]

# Apply jump
execute if data storage superstack:temp all{jump:true} if predicate superstack:on_ground run data modify entity @s Motion[1] set value 0.45

# Rotate to player's rotation
rotate @s ~ ~ 