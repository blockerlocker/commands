# Add 1 to player's superstack score.
scoreboard players add @p[tag=superstack] superstack 1

# If the entitiy has no vehicle, run the base tick function.
execute unless predicate superstack:has_vehicle positioned as @s run function zzz:superstack/base/tick

# If the entity has a vehicle, run this function as its vehicle.
execute on vehicle run function zzz:superstack/player/find_base