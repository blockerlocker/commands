data modify storage superstack:temp all.strafe_vector set from entity @s Pos
kill @s