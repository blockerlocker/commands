execute if predicate superstack:input/forward rotated ~ 0 positioned 0.0 0.0 0.0 positioned ^ ^ ^0.5 summon marker run function zzz:superstack/player/get_strafe_vector
execute if predicate superstack:input/backward rotated ~180 0 positioned 0.0 0.0 0.0 positioned ^ ^ ^0.5 summon marker run function zzz:superstack/player/get_strafe_vector
execute if predicate superstack:input/right rotated ~90 0 positioned 0.0 0.0 0.0 positioned ^ ^ ^0.5 summon marker run function zzz:superstack/player/get_strafe_vector
execute if predicate superstack:input/left rotated ~-90 0 positioned 0.0 0.0 0.0 positioned ^ ^ ^0.5 summon marker run function zzz:superstack/player/get_strafe_vector

execute if predicate superstack:input/forward_right rotated ~45 0 positioned 0.0 0.0 0.0 positioned ^ ^ ^0.5 summon marker run function zzz:superstack/player/get_strafe_vector
execute if predicate superstack:input/forward_left rotated ~-45 0 positioned 0.0 0.0 0.0 positioned ^ ^ ^0.5 summon marker run function zzz:superstack/player/get_strafe_vector
execute if predicate superstack:input/backward_right rotated ~135 0 positioned 0.0 0.0 0.0 positioned ^ ^ ^0.5 summon marker run function zzz:superstack/player/get_strafe_vector
execute if predicate superstack:input/backward_left rotated ~-135 0 positioned 0.0 0.0 0.0 positioned ^ ^ ^0.5 summon marker run function zzz:superstack/player/get_strafe_vector