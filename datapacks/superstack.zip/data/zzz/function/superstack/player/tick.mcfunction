# If the player has no vehicle, stack to nearest mob that has no passenger.
execute store success storage superstack:temp all.ride_success byte 1 unless predicate superstack:has_vehicle run ride @s mount @n[nbt={Brain:{}},distance=..2,predicate=!superstack:has_passenger,type=!player]
execute if data storage superstack:temp all{ride_success:true} run playsound minecraft:block.sniffer_egg.plop ui @s

# If a player is strafing, grab horizontal movement vector.
execute if entity @s[predicate=superstack:has_vehicle,predicate=superstack:strafing] run function zzz:superstack/player/strafe

# Store if player is jumping.
execute if predicate superstack:input/jump run data modify storage superstack:temp all.jump set value true

# Give player tag to identify them later
tag @s add superstack

# Reset the player's superstack score, which counts the number of mobs they are riding.
scoreboard players set @s superstack 0

# Find base entity to run base tick.
execute if predicate superstack:has_vehicle on vehicle run function zzz:superstack/player/find_base

# Display stack count .
title @s actionbar [{text:"Stack Size: ",color:aqua},{score:{name:"*",objective:"superstack"},color:gold},{text:" Mobs",color:gold}]

# Cleanup storage and remove identifying tag.
data remove storage superstack:temp all
tag @s remove superstack