# Remove the attributes from any mob that has no vehicle.
execute as @e[nbt={Brain:{}},predicate=!superstack:has_vehicle,type=!player] run function zzz:superstack/base/remove_attributes

# Run the tick function for each individual player.
execute as @a[gamemode=!spectator] at @s run function zzz:superstack/player/tick
